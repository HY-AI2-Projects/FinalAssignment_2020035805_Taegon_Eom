# cats and dogs > 2022-04-16 3:48pm
https://universe.roboflow.com/sree-69ula/cats-and-dogs-hapzd

Provided by a Roboflow user
License: CC BY 4.0

